#!/bin/bash

./vm -
