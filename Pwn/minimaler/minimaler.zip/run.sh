#!/bin/bash

LD_PRELOAD=./preload.so ./vuln
